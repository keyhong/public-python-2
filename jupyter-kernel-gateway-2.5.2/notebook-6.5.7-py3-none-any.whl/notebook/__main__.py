if __name__ == '__main__':
    from notebook import notebookapp as app
    app.launch_new_instance()
