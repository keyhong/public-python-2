from . import cpu
from . import gpu
